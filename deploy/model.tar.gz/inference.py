
import json
import pickle
import numpy as np
from scipy.stats import rankdata

# 安裝依賴（首次執行時）
import subprocess
import sys

def install_packages():
    packages = ["lightgbm", "xgboost", "catboost"]
    for pkg in packages:
        try:
            __import__(pkg)
        except ImportError:
            print(f"安裝 {pkg}...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", pkg])

install_packages()

# 重新 import
import lightgbm
import xgboost
try:
    import catboost
    CATBOOST_AVAILABLE = True
except:
    CATBOOST_AVAILABLE = False

def model_fn(model_dir):
    """載入模型"""
    print(f"[INFO] 載入模型從：{model_dir}")
    
    models = {}
    
    # 載入 LightGBM
    try:
        with open(f"{model_dir}/lightgbm.pkl", "rb") as f:
            models["Lightgbm"] = pickle.load(f)
            print("[INFO] ✅ LightGBM")
    except Exception as e:
        print(f"[WARN] LightGBM: {e}")
    
    # 載入 XGBoost
    try:
        with open(f"{model_dir}/xgboost.pkl", "rb") as f:
            models["Xgboost"] = pickle.load(f)
            print("[INFO] ✅ XGBoost")
    except Exception as e:
        print(f"[WARN] XGBoost: {e}")
    
    # 載入 CatBoost
    if CATBOOST_AVAILABLE:
        try:
            with open(f"{model_dir}/catboost.pkl", "rb") as f:
                models["Catboost"] = pickle.load(f)
                print("[INFO] ✅ CatBoost")
        except Exception as e:
            print(f"[WARN] CatBoost: {e}")
    
    # 載入配置
    with open(f"{model_dir}/feature_cols.json", "r") as f:
        feature_cols = json.load(f)
    
    with open(f"{model_dir}/best_thresholds.json", "r") as f:
        config = json.load(f)
    
    print(f"[INFO] 載入 {len(models)} 個模型，{len(feature_cols)} 個特徵")
    
    return {
        "models": models,
        "feature_cols": feature_cols,
        "threshold": config.get("Ensemble", 0.5),
        "weights": {"Lightgbm": 0.33, "Xgboost": 0.33, "Catboost": 0.34}
    }

def input_fn(request_body, content_type):
    """解析輸入"""
    if content_type == "application/json":
        data = json.loads(request_body)
        return np.array(data["features"])
    raise ValueError(f"不支援: {content_type}")

def predict_fn(input_data, model_dict):
    """執行預測"""
    models = model_dict["models"]
    threshold = model_dict["threshold"]
    weights = model_dict["weights"]
    
    if not models:
        raise ValueError("沒有可用的模型")
    
    # 預測
    prob_dict = {}
    for name, model in models.items():
        try:
            prob = model.predict_proba(input_data)[:, 1]
            prob_dict[name] = prob
        except Exception as e:
            print(f"[WARN] {name} 失敗: {e}")
    
    if not prob_dict:
        raise ValueError("所有模型都失敗")
    
    # Rank Ensemble
    ranked = {n: rankdata(p) / len(p) for n, p in prob_dict.items()}
    
    ensemble_prob = np.zeros(len(input_data))
    total_weight = 0
    
    for name, prob in ranked.items():
        w = weights.get(name, 1.0 / len(ranked))
        ensemble_prob += w * prob
        total_weight += w
    
    if total_weight > 0:
        ensemble_prob /= total_weight
    
    predictions = (ensemble_prob >= threshold).astype(int)
    
    return {
        "predictions": predictions.tolist(),
        "risk_scores": ensemble_prob.tolist(),
        "threshold": float(threshold)
    }

def output_fn(prediction, accept):
    """格式化輸出"""
    return json.dumps(prediction), "application/json"
